#ifndef SEGMENT_H
#define SEGMENT_H

#include "point.h"
class Segment {
    public:
    Point d1, d2; // 公有成员变量

    // 默认构造函数（不需要显式定义）
    Segment(double a1 = 0, double b1 = 0, double a2 = 0, double b2 = 0) : d1{a1, b1}, d2{a2, b2} {}

    void setP1(double a, double b); // 设置端点1的坐标
    void setP2(double a, double b); // 设置端点2的坐标
    void getP1(double& a, double& b) const; // 获取端点1的坐标
    void getP2(Point& p) const; // 获取端点2的值
    double calLen() const; // 计算线段长度
    void show() const; // 显示线段信息
};

#endif