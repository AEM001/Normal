#include "point.h"

// 设置点的坐标
void Point::set(double a, double b) {
    x = a;
    y = b;
}

// 获取点的坐标
void Point::get(double& a, double& b) const {
    a = x;
    b = y;
}

// 计算与另一个点的距离
double Point::dis(const Point& d) const {
    double dx = x - d.x;
    double dy = y - d.y;
    return sqrt(dx * dx + dy * dy);
}

// 计算与指定坐标的距离
double Point::dis(double a, double b) const {
    double dx = x - a;
    double dy = y - b;
    return sqrt(dx * dx + dy * dy);
}

// 显示点的坐标
void Point::show() const {
    cout << "(" << x << ", " << y << ")";
}