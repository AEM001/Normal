#ifndef POINT_H
#define POINT_H

#include <cmath>
#include <iostream>
using namespace std;

struct Point {
    double x, y; // 公有成员变量

    // 默认构造函数（不需要显式定义）
    Point(double a = 0, double b = 0) : x(a), y(b) {}

    void set(double a, double b);      // 设置点的坐标
    void get(double& a, double& b) const; // 获取点的坐标
    double dis(const Point& d) const;  // 计算与另一个点的距离
    double dis(double a, double b) const; // 计算与指定坐标的距离
    void show() const;                 // 显示点的坐标
};

#endif