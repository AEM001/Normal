#include "segment.h"

// 设置端点1的坐标
void Segment::setP1(double a, double b) {
    d1.set(a, b);
}

// 设置端点2的坐标
void Segment::setP2(double a, double b) {
    d2.set(a, b);
}

// 获取端点1的坐标
void Segment::getP1(double& a, double& b) const {
    d1.get(a, b);
}

// 获取端点2的值
void Segment::getP2(Point& p) const {
    p = d2;
}

// 计算线段长度
double Segment::calLen() const {
    return d1.dis(d2);
}

// 显示线段信息
void Segment::show() const {
    d1.show();
    cout << " ";
    d2.show();
    cout << ", length = " << calLen() << endl;
}